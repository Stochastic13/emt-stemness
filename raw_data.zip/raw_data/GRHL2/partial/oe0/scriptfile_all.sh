#!/bin/bash
./RACIPE.exe grhl2partial1.topo -num_paras 10000 -seed 1 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_1 &
sleep 2m
./RACIPE.exe grhl2partial2.topo -num_paras 10000 -seed 2 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_2 &
sleep 2m
./RACIPE.exe grhl2partial3.topo -num_paras 10000 -seed 3 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_3 &
sleep 2m
./RACIPE.exe grhl2partial4.topo -num_paras 10000 -seed 4 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_4 &
sleep 2m
./RACIPE.exe grhl2partial5.topo -num_paras 10000 -seed 5 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_5 &