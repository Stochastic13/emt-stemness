#!/bin/bash
./RACIPE.exe grhl2full1.topo -num_paras 10000 -seed 1 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 -DEID 1 -DEFD 10 > termoutput_1 &
sleep 2m
./RACIPE.exe grhl2full2.topo -num_paras 10000 -seed 2 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 -DEID 1 -DEFD 10 > termoutput_2 &
sleep 2m
./RACIPE.exe grhl2full3.topo -num_paras 10000 -seed 3 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 -DEID 1 -DEFD 10 > termoutput_3 &
sleep 2m
./RACIPE.exe grhl2full4.topo -num_paras 10000 -seed 4 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 -DEID 1 -DEFD 10 > termoutput_4 &
sleep 2m
./RACIPE.exe grhl2full5.topo -num_paras 10000 -seed 5 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 -DEID 1 -DEFD 10 > termoutput_5 &