#!/bin/bash
./RACIPE.exe emt.topo -num_paras 10000 -seed 1 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_1 &
sleep 2m
./RACIPE.exe stemness.topo -num_paras 10000 -seed 2 -num_ode 200 -minP 1 -maxP 500 -num_stability 15 > termoutput_2 &